define i32 @not(i32 %p) {
entry:
    %is_zero = icmp eq i32 %p, 0
    %res = zext i1 %is_zero to i32
    ret i32 %res
}
