#include <stdio.h>

int not(int p);
int main() {
    printf("%d\n", not(1));
    printf("%d\n", not(0));
}
